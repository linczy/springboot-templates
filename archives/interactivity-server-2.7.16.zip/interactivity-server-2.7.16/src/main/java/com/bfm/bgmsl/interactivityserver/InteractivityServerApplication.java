package com.bfm.bgmsl.interactivityserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InteractivityServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(InteractivityServerApplication.class, args);
	}

}
