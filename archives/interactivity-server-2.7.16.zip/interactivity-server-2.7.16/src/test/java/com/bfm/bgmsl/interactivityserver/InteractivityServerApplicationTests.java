package com.bfm.bgmsl.interactivityserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InteractivityServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
